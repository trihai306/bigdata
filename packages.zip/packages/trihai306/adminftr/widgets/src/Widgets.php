<?php

namespace Future\Widgets;

class Widgets
{
    // Build wonderful things
}
