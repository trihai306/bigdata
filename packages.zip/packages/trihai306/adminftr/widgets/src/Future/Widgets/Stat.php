<?php
namespace Future\Future\Widgets;

use Livewire\Component;

class Stat extends Widget
{
}
