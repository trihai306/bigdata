# Changelog

All notable changes to `Notifications` will be documented in this file.

## Version 1.0

### Added
- Everything
