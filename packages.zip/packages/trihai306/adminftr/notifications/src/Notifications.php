<?php

namespace Future\Notifications;

class Notifications
{
    // Build wonderful things
}