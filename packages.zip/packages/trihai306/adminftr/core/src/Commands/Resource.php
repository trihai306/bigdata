<?php

namespace Future\Core\Commands;

use Illuminate\Console\Command;

class Resource extends Command
{
    protected $signature = 'future:resource';
    protected $description = "Create a new resource";
}
