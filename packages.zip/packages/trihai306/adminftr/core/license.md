# The license

Copyright (c) Author Name <author@email.com>

...Add your license text here...