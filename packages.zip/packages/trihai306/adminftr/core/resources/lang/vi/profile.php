<?php

return [
    'my_account' => 'Tài khoản của tôi',
    'profile_details' => 'Chi tiết hồ sơ',
    'change_avatar' => 'Thay đổi ảnh đại diện',
    'profile' => 'Hồ sơ',
    'name' => 'Tên',
    'phone' => 'Số điện thoại',
    'birthday' => 'Ngày sinh',
    'email' => 'Email',
    'email_subtitle' => 'Tiêu đề phụ Email',
    'change' => 'Thay đổi',
    'password' => 'Mật khẩu',
    'password_subtitle' => 'Tiêu đề phụ Mật khẩu',
    'set_new_password' => 'Đặt mật khẩu mới',
    'submit' => 'Gửi',
    'settings' => 'Cài đặt',
    'my_notifications' => 'Thông báo của tôi',
    'plans' => 'Kế hoạch',
];
