<?php

return [
    'title' => 'Trang 404 - Tabler - Mẫu bảng điều khiển chất lượng cao và mã nguồn mở với giao diện người dùng đáp ứng.',
    'oops' => 'Rất tiếc… Bạn vừa tìm thấy một trang lỗi',
    'not_found' => 'Chúng tôi rất tiếc nhưng trang bạn đang tìm kiếm không được tìm thấy',
    'take_me_home' => 'Đưa tôi về nhà',
];
