<?php
return [
    'back' => 'Quay lại',
    'save' => 'Lưu',
    'please_wait' => 'Vui lòng đợi...',
    'reset' => 'Đặt lại',
    'close' => 'Đóng',
];
