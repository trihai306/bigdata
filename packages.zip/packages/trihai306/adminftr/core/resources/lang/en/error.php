<?php

return [
    'title' => 'Page 404 - Tabler - Premium and Open Source dashboard template with responsive and high quality UI.',
    'oops' => 'Oops… You just found an error page',
    'not_found' => 'We are sorry but the page you are looking for was not found',
    'take_me_home' => 'Take me home',
];
