<?php

namespace Future\Messages;

class Messages
{
    // Build wonderful things
}