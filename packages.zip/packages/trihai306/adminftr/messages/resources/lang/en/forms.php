<?php
return [
    'back' => 'Back',
    'save' => 'Save',
    'please_wait' => 'Please wait...',
    'reset' => 'Reset',
];
