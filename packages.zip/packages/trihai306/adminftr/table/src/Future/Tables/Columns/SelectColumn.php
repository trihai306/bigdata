<?php
namespace Future\Table\Future\Tables\Columns;


use Future\Table\Future\Tables\Column;

class SelectColumn extends Column
{

}
