# Changelog

All notable changes to `Table` will be documented in this file.

## Version 1.0

### Added
- Everything
