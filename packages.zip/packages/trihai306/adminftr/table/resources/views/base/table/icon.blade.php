<div>
    <i class='{{$icon}} {{$color}} {{$class}}' style='font-size: {{$size}};' title='{{$tooltip}}' aria-hidden='{{$ariaHidden}}' role='{{$role}}'></i>
</div>
